from django.contrib import admin

from .models import Onu

# Register your models here.
admin.site.register(Onu)
