from django.contrib import admin

from .models import Pop

# Register your models here.
admin.site.register(Pop)
